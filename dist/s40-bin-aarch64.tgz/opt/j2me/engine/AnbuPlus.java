/*
	Giao diện SDL ("Anbu") cho lõi FreeJ2ME-Plus: gửi khung hình sang tiến trình sdl_interface và nhận phím từ nó.
	Dựa trên Anbu.java của FreeJ2ME (GPLv3) và Libretro.java của FreeJ2ME-Plus.

	This file is part of FreeJ2ME.

	FreeJ2ME is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	FreeJ2ME is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeJ2ME.  If not, see http://www.gnu.org/licenses/
*/
package org.recompile.freej2me;

import org.recompile.mobile.Mobile;
import org.recompile.mobile.MobilePlatform;
import org.recompile.mobile.PlatformImage;

import javax.microedition.lcdui.Canvas;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Timer;
import java.util.TimerTask;

public class AnbuPlus
{
	public static void main(String[] args)
	{
		Mobile.clearOldLog();
		new AnbuPlus(args);
	}

	private int lcdWidth = 240, lcdHeight = 320;
	private volatile int[] lcdData;
	private byte[] frame;
	private OutputStream toSdl;
	private InputStream fromSdl;
	private Process proc;
	private final boolean[] pressed = new boolean[256];
	private int lastRepeatKey = 0;
	private long keyTime = 0;

	public AnbuPlus(String[] args)
	{
		if (args.length < 3) { System.out.println("Insufficient parameters provided"); return; }
		lcdWidth = Integer.parseInt(args[1]);
		lcdHeight = Integer.parseInt(args[2]);

		// Thư mục dữ liệu (RMS, cấu hình từng game): -Dfreej2me.data=<thư mục>
		String data = System.getProperty("freej2me.data");

		Mobile.setPlatform(new MobilePlatform(lcdWidth, lcdHeight), new Runnable() { public void run() { settingsChanged(); } });
		if (data != null) Mobile.getPlatform().dataPath = data.endsWith("/") ? data : data + "/";

		Mobile.getPlatform().setPainter(new Runnable() { public void run() { sendFrame(); } });

		String file = getFormattedLocation(args[0]);
		System.out.println(file);

		if (Mobile.getPlatform().load(file))
		{
			// Cấu hình giống như bản Libretro: nạp xong jar rồi mới đặt thông số
			Mobile.config.settings.put("scrwidth", "" + lcdWidth);
			Mobile.config.settings.put("scrheight", "" + lcdHeight);
			Mobile.config.settings.put("rotate", "0");
			Mobile.config.settings.put("phone", System.getProperty("freej2me.phone", "Standard"));
			Mobile.config.settings.put("fps", System.getProperty("freej2me.fps", "30"));
			Mobile.config.sysSettings.put("sound", System.getProperty("freej2me.sound", "on"));
			// Chế độ 3D nhanh: giảm tải cho M3G / Mascot Capsule (vẽ bằng CPU nên rất nặng trên RK3326)
			if ("on".equals(System.getProperty("freej2me.fast3d", "off")))
			{
				Mobile.config.settings.put("spdhackm3ghalfres", "on");
				Mobile.config.settings.put("spdhackmcv3halfres", "on");
				Mobile.config.settings.put("spdhackmcv3nolighting", "on");
				Mobile.config.settings.put("m3gantialiasmode", "off");
				Mobile.config.settings.put("m3gbilinearmode", "off");
				Mobile.config.settings.put("m3gditheringmode", "off");
				Mobile.config.settings.put("m3gmipmapmode", "off");
			}
			settingsChanged();

			startSdl(args);
			Mobile.getPlatform().runJar();
		}
		else
		{
			System.out.println("Couldn't load jar...");
			System.exit(0);
		}
	}

	private void settingsChanged()
	{
		Mobile.updateSettings();
		if (lcdWidth != Mobile.lcdWidth || lcdHeight != Mobile.lcdHeight)
		{
			lcdWidth = Mobile.lcdWidth;
			lcdHeight = Mobile.lcdHeight;
			Mobile.getPlatform().resizeLCD(lcdWidth, lcdHeight);
		}
		lcdData = Mobile.getPlatform().getLcdFrontbuffer().getDataBuffer();
		frame = new byte[lcdWidth * lcdHeight * 3];
	}

	private void sendFrame()
	{
		try
		{
			int[] d;
			PlatformImage fb = Mobile.getPlatform().getLcdFrontbuffer();
			synchronized (fb)
			{
				d = fb.getDataBuffer();
				int n = lcdWidth * lcdHeight;
				if (frame == null || frame.length != n * 3) frame = new byte[n * 3];
				int c = 0;
				for (int i = 0; i < n; i++)
				{
					int p = d[i];
					frame[c++] = (byte) (p >> 16);
					frame[c++] = (byte) (p >> 8);
					frame[c++] = (byte) p;
				}
			}
			toSdl.write(frame);
			toSdl.flush();
		}
		catch (Exception e) { }
	}

	private static String getFormattedLocation(String loc)
	{
		if (loc.startsWith("file://") || loc.startsWith("http://")) return loc;
		File file = new File(loc);
		if (!file.exists() || file.isDirectory()) { System.out.println("File not found..."); System.exit(0); }
		return "file://" + file.getAbsolutePath();
	}

	private void startSdl(String[] args)
	{
		try
		{
			String[] a = args.clone();
			a[0] = System.getProperty("anbu.interface", "/usr/local/bin/sdl_interface");
			proc = new ProcessBuilder(a).start();
			fromSdl = proc.getInputStream();
			toSdl = proc.getOutputStream();
			new Timer(true).schedule(new KeyTask(), 0, 5);
			// lặp phím giữ lâu (như máy thật): sau 350ms, mỗi 33ms
			new Timer(true).schedule(new TimerTask() { public void run() { repeatTick(); } }, 0, 33);
		}
		catch (Exception e)
		{
			System.out.println("Failed to start sdl_interface: " + e.getMessage());
			System.exit(0);
		}
	}

	private void repeatTick()
	{
		if (lastRepeatKey != 0 && pressed[(lastRepeatKey + 64) & 0xFF] && System.currentTimeMillis() - keyTime >= 350)
		{
			MobilePlatform.keyRepeated(lastRepeatKey);
		}
	}

	private class KeyTask extends TimerTask
	{
		private final byte[] din = new byte[6];
		private int count = 0;

		public void run()
		{
			try
			{
				while (true)
				{
					int bin = fromSdl.read();
					if (bin == -1) { System.exit(0); }
					din[count++] = (byte) (bin & 0xFF);
					if (count == 5)
					{
						count = 0;
						int code = ((din[1] & 0xFF) << 24) | ((din[2] & 0xFF) << 16) | ((din[3] & 0xFF) << 8) | (din[4] & 0xFF);
						int key;
						switch (din[0] >>> 1)
						{
							case 0: key = keyboardKey(code); break;
							case 1: key = padKey(code); break;
							case 2: key = joyKey(code); break;
							default: continue;
						}
						if (key == 0) continue;
						int idx = (key + 64) & 0xFF;
						if (din[0] % 2 == 0)
						{
							MobilePlatform.keyReleased(key);
							pressed[idx] = false;
							if (lastRepeatKey == key) lastRepeatKey = 0;
						}
						else
						{
							if (!pressed[idx]) { MobilePlatform.keyPressed(key); keyTime = System.currentTimeMillis(); lastRepeatKey = key; }
							pressed[idx] = true;
						}
					}
				}
			}
			catch (Exception e) { }
		}
	}

	private int keyboardKey(int keycode)
	{
		switch (keycode)
		{
			case 0x30: return Canvas.KEY_NUM0;
			case 0x31: return Canvas.KEY_NUM1;
			case 0x32: return Canvas.KEY_NUM2;
			case 0x33: return Canvas.KEY_NUM3;
			case 0x34: return Canvas.KEY_NUM4;
			case 0x35: return Canvas.KEY_NUM5;
			case 0x36: return Canvas.KEY_NUM6;
			case 0x37: return Canvas.KEY_NUM7;
			case 0x38: return Canvas.KEY_NUM8;
			case 0x39: return Canvas.KEY_NUM9;
			case 0x2A: return Canvas.KEY_STAR;
			case 0x23: return Canvas.KEY_POUND;
			case 0x40000052: return Canvas.KEY_NUM2;
			case 0x40000051: return Canvas.KEY_NUM8;
			case 0x40000050: return Canvas.KEY_NUM4;
			case 0x4000004F: return Canvas.KEY_NUM6;
			case 0x0D: return Canvas.KEY_NUM5;
			case 0x08: return -8;   // phím xóa (C)
			case 0x71: return Mobile.NOKIA_SOFT1;
			case 0x77: return Mobile.NOKIA_SOFT2;
			case 0x65: return Canvas.KEY_STAR;
			case 0x72: return Canvas.KEY_POUND;
			case 0x40000059: return Canvas.KEY_NUM7;
			case 0x4000005A: return Canvas.KEY_NUM8;
			case 0x4000005B: return Canvas.KEY_NUM9;
			case 0x4000005C: return Canvas.KEY_NUM4;
			case 0x4000005D: return Canvas.KEY_NUM5;
			case 0x4000005E: return Canvas.KEY_NUM6;
			case 0x4000005F: return Canvas.KEY_NUM1;
			case 0x40000060: return Canvas.KEY_NUM2;
			case 0x40000061: return Canvas.KEY_NUM3;
			case 0x40000062: return Canvas.KEY_NUM0;
			case -1: System.exit(0);
			case 0x1B: System.exit(0);
		}
		return 0;
	}

	private int padKey(int keycode)
	{
		switch (keycode)
		{
			case 0x03: return Canvas.KEY_NUM0;
			case 0x02: return Canvas.KEY_NUM5;
			case 0x00: return Canvas.KEY_STAR;
			case 0x01: return Canvas.KEY_POUND;
			case 0x04: return Canvas.KEY_NUM1;
			case 0x05: return Canvas.KEY_NUM3;
			case 0x06: return Mobile.NOKIA_SOFT1;
			case 0x07: return Mobile.NOKIA_SOFT2;
		}
		return 0;
	}

	private int joyKey(int keycode)
	{
		switch (keycode)
		{
			case 0x04: return Canvas.KEY_NUM2;
			case 0x01: return Canvas.KEY_NUM4;
			case 0x02: return Canvas.KEY_NUM6;
			case 0x08: return Canvas.KEY_NUM8;
		}
		return 0;
	}
}
